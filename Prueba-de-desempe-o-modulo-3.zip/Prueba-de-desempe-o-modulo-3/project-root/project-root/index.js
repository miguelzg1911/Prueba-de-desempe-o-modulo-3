import { initRouter } from './script/routes';

window.addEventListener('DOMContentLoaded', () => {
  initRouter();
});

  document.body.addEventListener('click', function (e) {
    const link = e.target.closest('a.spa-link');
    if (link && link.href.startsWith(window.location.origin)) {
      e.preventDefault();
      history.pushState({}, '', link.getAttribute('href'));
      initRouter();
    }
  });

window.addEventListener('popstate', () => {
  initRouter();
});