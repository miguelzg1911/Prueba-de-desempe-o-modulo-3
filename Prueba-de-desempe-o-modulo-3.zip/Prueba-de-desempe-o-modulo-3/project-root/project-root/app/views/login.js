export function renderLogin(container) {
  container.innerHTML = `
    <div class="container">
      <h2>Iniciar Sesión</h2>
      <form id="loginForm">
        <input type="email" placeholder="Correo" required name="email">
        <input type="password" placeholder="Contraseña" required name="password">
        <button type="submit">Ingresar</button>
      </form>
    </div>
  `;

  document.getElementById('loginForm').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.target;
    const email = form.email.value;
    const password = form.password.value;

    try {
      const { loginUser } = await import('../../script/auth.js');
      await loginUser(email, password);
      location.href = '/dashboard';
    } catch (err) {
      alert(err.message);
    }
  });
}
