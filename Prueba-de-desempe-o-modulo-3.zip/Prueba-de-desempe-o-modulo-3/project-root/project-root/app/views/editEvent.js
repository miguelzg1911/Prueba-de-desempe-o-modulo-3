export async function renderEditEvent(container) {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get('id');

  const { getEvents, updateEvent } = await import('../../script/events.js');
  const event = (await getEvents()).find(e => e.id == id);

  if (!event) {
    container.innerHTML = '<p>Evento no encontrado.</p>';
    return;
  }

  container.innerHTML = `
    <div class="container">
      <h2>Editar Evento</h2>
      <form id="editForm">
        <input type="text" name="nombre" value="${event.nombre}" required>
        <input type="date" name="fecha" value="${event.fecha}" required>
        <input type="number" name="capacidad" value="${event.capacidad}" required>
        <button type="submit">Guardar Cambios</button>
      </form>
    </div>
  `;

  document.getElementById('editForm').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.target;
    const updated = {
      nombre: form.nombre.value,
      fecha: form.fecha.value,
      capacidad: Number(form.capacidad.value)
    };
    await updateEvent(id, updated);
    location.href = '/dashboard';
  });
}