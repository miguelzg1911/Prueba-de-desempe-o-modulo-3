export function renderCreateEvent(container) {
  container.innerHTML = `
    <div class="container">
      <h2>Crear Evento</h2>
      <form id="createForm">
        <input type="text" name="nombre" placeholder="Nombre del evento" required>
        <input type="date" name="fecha" required>
        <input type="number" name="capacidad" placeholder="Capacidad" required>
        <button type="submit">Crear</button>
      </form>
    </div>
  `;

  document.getElementById('createForm').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.target;
    const event = {
      nombre: form.nombre.value,
      fecha: form.fecha.value,
      capacidad: Number(form.capacidad.value)
    };
    const { createEvent } = await import('../../script/events.js');
    await createEvent(event);
    location.href = '/dashboard';
  });
}