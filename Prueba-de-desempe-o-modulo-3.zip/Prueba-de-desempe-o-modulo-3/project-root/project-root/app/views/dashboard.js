export async function renderDashboard(container) {
  const { getEvents } = await import('../../script/events.js');
  const { getSessionUser, logout } = await import('../../script/storage.js');

  const events = await getEvents();
  const user = getSessionUser();

  let html = `
    <div class="container">
      <h2>Bienvenido, ${user.name} (${user.rol})</h2>
      <button onclick="logout()">Cerrar Sesión</button>
      <h3>Eventos disponibles</h3>
      <ul>
  `;

  events.forEach(evt => {
    html += `<li>
      <strong>${evt.nombre}</strong> - ${evt.fecha} (${evt.capacidad} personas)
      ${user.rol === 'admin' ? `
        <a href="/dashboard/events/edit?id=${evt.id}" class="spa-link">Editar</a>
        <button onclick="deleteEvent(${evt.id})">Eliminar</button>
      ` : ''}
    </li>`;
  });

  html += '</ul>';

  if (user.rol === 'admin') {
    html += `<a href="/dashboard/events/create" class="spa-link">Crear nuevo evento</a>`;
  }

  html += `</div>`;
  container.innerHTML = html;

  window.logout = logout;

  if (user.rol === 'admin') {
    const { deleteEvent } = await import('../../script/events.js');
    window.deleteEvent = async (id) => {
      await deleteEvent(id);
      renderDashboard(container);
    };
  }
}