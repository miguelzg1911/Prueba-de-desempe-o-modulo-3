
export function renderNotFound(container) {
  container.innerHTML = `
    <div class="container">
      <h2>404 - Página no encontrada</h2>
      <a href="/dashboard">Volver al inicio</a>
    </div>
  `;
}

