export function renderRegister(container) {
  container.innerHTML = `
    <div class="container">
      <h2>Registro</h2>
      <form id="registerForm">
        <input type="text" placeholder="Nombre" required name="name">
        <input type="email" placeholder="Correo" required name="email">
        <input type="password" placeholder="Contraseña" required name="password">
        <select name="rol" required>
          <option value="" disabled selected>Selecciona rol</option>
          <option value="admin">Administrador</option>
          <option value="visitante">Visitante</option>
        </select>
        <button type="submit">Registrarse</button>
      </form>
    </div>
  `;

  document.getElementById('registerForm').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.target;
    const user = {
      name: form.name.value,
      email: form.email.value,
      password: form.password.value,
      rol: form.rol.value
    };

    try {
      const { registerUser } = await import('../../script/auth.js');
      await registerUser(user);
      alert('Usuario registrado correctamente');
      location.href = '/login';
    } catch (err) {
      alert(err.message);
    }
  });
}