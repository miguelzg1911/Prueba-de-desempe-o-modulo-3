
import { renderLogin } from '../app/views/login.js';
import { renderRegister } from '../app/views/register.js';
import { renderDashboard } from '../app/views/dashboard.js';
import { renderCreateEvent } from '../app/views/createEvent.js';
import { renderEditEvent } from '../app/views/editEvent.js';
import { renderNotFound } from '../app/views/not-found.js';
import { isAuthenticated } from './guards.js';

const routes = {
  '/login': renderLogin,
  '/register': renderRegister,
  '/dashboard': renderDashboard,
  '/dashboard/events/create': renderCreateEvent,
  '/dashboard/events/edit': renderEditEvent,
  '/404': renderNotFound
};

export function initRouter() {
  const app = document.getElementById('app');
  const path = window.location.pathname;

  if (path === '/') {
    if (isAuthenticated()) {
      history.replaceState({}, '', '/dashboard');
      path = '/dashboard';
    } else {
      history.replaceState({}, '', '/login');
      path = '/login';
    }
  }

  if (!isAuthenticated() && !['/login', '/register'].includes(path)) {
    history.pushState({}, '', '/404');
    return renderNotFound(app);
  }

  if (isAuthenticated() && ['/login', '/register'].includes(path)) {
    history.pushState({}, '', '/dashboard');
    return renderDashboard(app);
  }

  const render = routes[path] || renderNotFound;
  render(app);
}
