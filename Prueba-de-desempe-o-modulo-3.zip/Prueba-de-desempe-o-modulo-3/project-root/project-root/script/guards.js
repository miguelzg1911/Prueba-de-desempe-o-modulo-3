export function isAuthenticated() {
  return !!localStorage.getItem('session');
}
