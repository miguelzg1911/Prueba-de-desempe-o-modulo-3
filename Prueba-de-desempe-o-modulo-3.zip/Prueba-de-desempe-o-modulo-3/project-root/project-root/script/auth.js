const API = 'http://localhost:3000/users';

export async function registerUser(user) {
  const res = await fetch(API);
  const users = await res.json();

  const exists = users.find(u => u.email === user.email);
  if (exists) throw new Error('El usuario ya existe');

  const response = await fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(user)
  });

  return await response.json();
}

export async function loginUser(email, password) {
  const res = await fetch(`${API}?email=${email}&password=${password}`);
  const [user] = await res.json();
  if (!user) throw new Error('Credenciales inválidas');

  localStorage.setItem('session', JSON.stringify(user));
  return user;
}