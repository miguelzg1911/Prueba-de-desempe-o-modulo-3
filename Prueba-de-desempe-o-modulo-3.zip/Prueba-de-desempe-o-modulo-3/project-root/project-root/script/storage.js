export function getSessionUser() {
  return JSON.parse(localStorage.getItem('session'));
}

export function logout() {
  localStorage.removeItem('session');
  location.href = '/login';
}
