const API = 'http://localhost:3000/events';

export async function getEvents() {
  const res = await fetch(API);
  return await res.json();
}

export async function createEvent(event) {
  const res = await fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(event)
  });
  return await res.json();
}

export async function updateEvent(id, updated) {
  const res = await fetch(`${API}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updated)
  });
  return await res.json();
}

export async function deleteEvent(id) {
  const res = await fetch(`${API}/${id}`, { method: 'DELETE' });
  return await res.json();
}
